// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
package com.mojang.datafixers.util;

public enum Unit {
    INSTANCE;

    @Override
    public String toString() {
        return "Unit";
    }
}
