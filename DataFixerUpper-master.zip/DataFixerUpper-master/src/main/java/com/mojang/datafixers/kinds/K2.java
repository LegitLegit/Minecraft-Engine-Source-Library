// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
package com.mojang.datafixers.kinds;

// (A, B) -> F<A, B>
public interface K2 {
}
